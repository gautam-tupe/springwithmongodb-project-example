package com.crud.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.crud.dao.EmployeeDao;
import com.crud.model.Employee;
import com.crud.model.Status;

@Service
public class EmployeeServiceImpl implements EmployeeService {

	@Autowired
	EmployeeDao employeeDao;

	@Override
	public Status save(Employee employee) {
		Status status = new Status();
		Employee emp = employeeDao.save(employee);
		if(emp !=null) {
			status.setCode(200);
			status.setMessage("Record save successfully.");
		} else {
			status.setCode(201);
			status.setMessage("Fail.");
		}
		
		return status;
	
	}

}
