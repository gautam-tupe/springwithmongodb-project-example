package com.crud.services;

import com.crud.model.Employee;
import com.crud.model.Status;

public interface EmployeeService {

	Status save(Employee employee);
	
}
