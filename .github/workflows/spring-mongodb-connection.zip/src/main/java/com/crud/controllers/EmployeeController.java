package com.crud.controllers;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.crud.model.Employee;
import com.crud.model.Status;
import com.crud.services.EmployeeService;

@RestController
@RequestMapping(value="employee")
public class EmployeeController {
	
	@Autowired
	EmployeeService employeeService;
	
	@RequestMapping(value="/save",method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Status> save(@RequestBody Employee employee) {
		System.out.println(employee);
		return  new ResponseEntity<Status>(employeeService.save(employee), HttpStatus.OK); // .save(employee);
		// return "success................";
		//return new ResponseEntity<Status>(employeeService.save(employee), HttpStatus.OK);
	}

	
}
