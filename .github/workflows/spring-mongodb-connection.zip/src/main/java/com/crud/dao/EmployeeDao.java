package com.crud.dao;

import com.crud.model.Employee;
import com.crud.model.Status;

public interface EmployeeDao {

	Employee save(Employee employee);
	
}
