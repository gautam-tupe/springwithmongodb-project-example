package com.crud.dao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.crud.model.Employee;
import com.crud.model.SequenceId;
import com.crud.repositories.EmployeeRepository;

@Repository
public class EmployeeDaoImpl implements EmployeeDao {

	@Autowired
	EmployeeRepository employeeRepository;
	
	private static final String HOSTING_SEQ_KEY = "hosting";
	
	@Autowired
	SequenceDao sequenceDao;
	
	@Override
	public Employee save(Employee employee) {
		employee.setId(sequenceDao.getNextSequenceId(HOSTING_SEQ_KEY));
		return employeeRepository.save(employee);
	}

	
}
